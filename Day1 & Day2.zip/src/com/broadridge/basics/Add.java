package com.broadridge.basics;

import java.lang.Math;
import java.util.Scanner;

public class Add {
	public static void main(String[] args) {
		// // 1. variable [ local,instance,class]
		// // a. must be declared
		// // b. initialize a value
		// // c. you can use the variable with the scope
		// int i = 1000;
		// int j = 20;
		// System.out.println("i*j = " + (i * j));
		//
		// byte b = 70;
		// int a = b;
		// System.out.println("b = " + b);
		// System.out.println("a = " + a);
		//
		// int c = 30;
		// byte b1 = (byte) i;
		//
		// System.out.println("c = " + c);
		// System.out.println("b1 = " + b1);
		//
		// int d; // only once with in a scope
		// d = 200;
		// System.out.println("d = " + d);
		// d = 3000;
		// System.out.println("d = " + d);
		// // a. intialization
		// // static
		// // dynamic - *********
		//
		// float f = 10.05f;
		// float f1 = 12.05f;
		// float f2 = f + f1;
		// System.out.println(f2);
		//
		// System.out.println(Math.sqrt(256));

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a value");
		int num = scanner.nextInt();
		int counter = 2;
		boolean b = false;

		while (counter < num) {
			if (num % counter == 0) {
				System.out.println(counter  +" " + num/counter);
				b = true;
				break;
			}
			counter++;
		}
		if (b) {
			System.out.println("Given is not a prime number " + num);
		} else {
			System.out.println("Given is a prime number " + num);
		}
	}

}

/*
 * Building blocks 1. comments [//(single), (mutiple), documentations 2.
 * Identifiers - names a. allowed [a-z,A-Z,0-9,$,_] b. can't start with number
 * c. Should not be a reserved word c. no space d. a and A both different 3.
 * Reserved words -(53) - appear in small case 4. separators {},[],;,,. 5.
 * operators (1. Arithmetic(+,-,*,/,%) 2.Relational(<,>,<=,>=,=,==)
 * 3.Logical(&&(and),||(or)) ) - logic 6. Data (values,literals)
 */