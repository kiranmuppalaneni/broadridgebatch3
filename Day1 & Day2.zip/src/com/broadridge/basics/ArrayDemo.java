package com.broadridge.basics;

import java.util.Scanner;

public class ArrayDemo {
	public static void main(String[] args) {
		// Store group of integer values
		// An array is index based and group similar type of values which can be
		// referred by a single variable
		// int[] i = new int[10];
		//
		//// System.out.println(i[7]);
		//
		// i[6] = 600;
		//
		// for (int index = 0 ; index < i.length ; index++) {
		// System.out.println(i[index]);
		// }

		// int start = 5;

		// for (int index = 0 ; index < i.length ; index++) {
		// i[index] = start;
		// start+=5;
		// }
		//
		// for (int index = 0 ; index < i.length ; index++) {
		// System.out.println(i[index]);
		// }
		//
		// int j = i[400]; // if index is not present it throws an ArrayIndex out of
		// bounds exception.
		// System.out.println(j);

		// int[] a = new int[10];
		//// a[0]= 5;a[1]=10;a[2]=15;
		//
		// for (int index = 0 ; index < a.length ; index++) {
		// a[index] = start;
		// start+=5;
		// }
		//
		// // Sum of total numbers in an array
		// int total = 0;
		// for (int index = 0 ; index < a.length ; index++) {
		// total = total + a[index];
		// System.out.println("Total = " + total + " value "+ a[index]);
		// }
		// System.out.println("Total = " + total);

		// int[] s;
		// s = new int[10];

		// int[] b = {10,12,34,56,232,676,789,232,121,121,565};
		// for (int index = 0 ; index < b.length ; index++) {
		// System.out.println(b[index]);
		// }

		// int[] b = { 10, 12, 34, 56, 232, 676, 789, 232, 121, 121, 565 };
		// Scanner scaner = new Scanner(System.in);
		// System.out.println("Enter the value for search");
		// int input = scaner.nextInt();
		// boolean found = false;
		// for (int index = 0; index < b.length; index++) {
		// if (b[index] == input) {
		// System.out.println(input + " found in " + index);
		// found = true;
		// }
		// }
		// if (!found) {
		// System.out.println(input + " is not found ");
		// }

		// int[][] k = new int[2][2];
		// System.out.println(k[0][0]);
		// k[0][0] = 234;
		// System.out.println(k[0][0]);

		String[] str = { "Hello", "World", "Java", "India", "Broadridge" };
		Scanner scaner = new Scanner(System.in);
		System.out.println("Enter the value ");
		String searchString = scaner.next();

		for (int index = 0; index < str.length; index++) {
			// System.out.println(str[index]);
			if (str[index].equals(searchString)) {
				System.out.println(searchString +" is found " + index);
			}
		}

		// int[] i = new int[10];
		// Scanner scaner = new Scanner(System.in);
		// for (int index = 0; index < i.length; index++) {
		// System.out.println("Enter the value for index " + index);
		// int value = scaner.nextInt();
		// i[index] = value;
		// }
		//
		//
		// for (int index = 0 ; index < i.length ; index++) {
		// System.out.println(i[index]);
		// }
	}
}
