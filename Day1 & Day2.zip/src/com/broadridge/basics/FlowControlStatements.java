package com.broadridge.basics;

public class FlowControlStatements {
	public static void main(String[] args) {
		// vaccine age > 60
		// int age = 60;
		// if (age >= 60) {
		// int vid = 1213243;
		// System.out.println("eligible for phase 1 vaccine" + vid);
		// } else if (age >= 45) {
		// System.out.println("eligible for phase 2 vaccine");
		// } else {
		// System.out.println("eligible for phase 3 vaccine");
		// }
		//
		// System.out.println("End of program");
		//
		// int option = 2;
		// switch (option) {
		// case 1:
		// System.out.println("withdraw");
		// case 2:
		// System.out.println("ministatement");
		// break;
		// case 3:
		// System.out.println("balance");
		// break;
		// case 4:
		// System.out.println("change pin");
		// break;
		// default:
		// System.out.println("wrong option selected");
		// }

		// int i = 1; // declare
		// while (i <= 10) { //true // check the condition
		// System.out.println("java");
		// i = i+1; // inc/dec
		// }

		// int i = 1;
		// do {
		// System.out.println("java");
		// i = i + 1;
		// } while (i <= 10);
		// 1.ini 2.cond 4.inc/dec
		//
		for (int i = 0; i <= 10; i++) {
			System.out.println("java" + i); // 3. body
		}

		// 5 * 1 =  5
		// 5 * 2 = 10
		
		int table = 5;
		for (int i = 1; i <= 100; i++) {
			System.out.println(table + "*" + i +" = "+ (table * i));
		}
		
		System.out.println("End of program");
	}
}

// Flow control stmts
// Conditional stmts :1. if & 2. switch
// iterative stmts : 1.do- while 2. while 3. for - repeatedly *****
// branch stmts : 1. break 2. continue 3. return