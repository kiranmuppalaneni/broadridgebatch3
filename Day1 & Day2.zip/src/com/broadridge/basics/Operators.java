package com.broadridge.basics;

public class Operators {
	public static void main(String[] args) {
		
		int i = 10;
		int j = 20;
		int k = i+j;    // numerics and return numerics
		
		int a = 100;
//		a = a + 200;
        a += 200;
        a -= 50;
		
		System.out.println(a);
//		int b =  a+200;
		
		int d = 5;
		++d ; // d=d+1;
		System.out.println(d);
		
		System.out.println(d==a); // relational input as numeric decision
		System.out.println(d<a); 
		System.out.println(d>a); 
		System.out.println(d<=a); 
		boolean b3 = (d==a);
		
//		with draw   amount < balance && amount > 100  // Logical &&(and) ||(or)
		
		
		
		
		
	}
	
}


/*Building blocks
   1. comments [//(single), (mutiple), documentations
   2. Identifiers - names 
       a. allowed [a-z,A-Z,0-9,$,_]
       b. can't start with number
       c. Should not be a reserved word
       c. no space
       d. a and A both different
   3. Reserved words -(53) - appear in small case
   4. separators {},[],;,,.
   5. operators (1. Arithmetic(+,-,*,/,%) 2.Relational(<,>,<=,>=,=,==) 3.Logical(&&(and),||(or))  ) - logic
   6. Data (values,literals)
 */