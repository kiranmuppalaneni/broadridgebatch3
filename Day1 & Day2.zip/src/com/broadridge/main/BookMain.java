package com.broadridge.main;

import com.broadridge.oop.Book;

public class BookMain {
	public static void main(String[] args) {
		Book book1 = new Book();
		book1.bookId=1001;
		book1.tilte = "Head First Java";
		book1.author="Martin";
		book1.noOfPages =150;
		book1.price= 200;
		book1.publisher="publisher1";
		book1.subject = "Java";
		
//		System.out.println(book1.bookId);
//		System.out.println(book1.tilte);
//		System.out.println(book1.author);
//		System.out.println(book1.price);
//		System.out.println(book1.subject);
//		System.out.println(book1.publisher);
//		System.out.println(book1.noOfPages);
		
		Book book2 = new Book();
		book2.bookId=1002;
		book2.tilte = "Complete reference";
		book2.author="John";
		book2.noOfPages =500;
		book2.price= 1200;
		book2.publisher="publisher2";
		book2.subject = "Java";
		
//		System.out.println(book2.bookId );
//		System.out.println(book2.tilte);
//		System.out.println(book2.author);
		System.out.println(book2.price);
//		System.out.println(book2.subject);
//		System.out.println(book2.publisher);
//		System.out.println(book2.noOfPages);
		System.out.println(book2);
		System.out.println(book1);
		
	}
}
