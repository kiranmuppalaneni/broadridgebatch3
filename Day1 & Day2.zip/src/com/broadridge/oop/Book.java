package com.broadridge.oop;

// Creating an structure
public class Book {
	public int bookId;
	public String tilte;
	public String author;//
	public String publisher;
	public String subject;
	public int noOfPages;
	public double price;
//	@Override
//	public String toString() {
//		return "Book [bookId=" + bookId + ", tilte=" + tilte + ", author=" + author + ", publisher=" + publisher
//				+ ", subject=" + subject + ", noOfPages=" + noOfPages + ", price=" + price + "]";
//	}
	
}
