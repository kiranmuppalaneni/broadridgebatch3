package com.broadridge.oop;

// 26 Employee details
// User defined datatype
public class Employee {
	public int employeeId;
	public Name name;
	public String email;
	public String project; // name,startdate,budget,resources
	public long phone;
}
