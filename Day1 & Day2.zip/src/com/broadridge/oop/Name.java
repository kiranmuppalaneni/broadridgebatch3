package com.broadridge.oop;

// Creating an structure
public class Name {
	public String firstName;
	public String lastName;
	public String middleName;	
	
	public static void main(String[] args) {
		Name name1 = new Name(); // object
	}
}
